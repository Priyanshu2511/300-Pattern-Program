class program14
{
   public static void main(String args[])
  {
       
       for(int j=1;j<=5;j++)
       {
              for(char i=101;i>=97;i--)
             {
                  System.out.print(i);
             }
              System.out.println();
      }

   



  }

}