/*
*****
   *
  *
 *
*****

*/
class uniquepattern13
{
public static void main(String args[])
 {
   int n=5;
   for(int i=1;i<=n;i++ )
    {
      for(int j=1,j1=n;j<=n||j1>=1;j++,j1--)
       {
       if(i==1||i==n||i==j1)
         System.out.print("*");
       else
         System.out.print(" ");
       }
       System.out.println();
    }

 }
}