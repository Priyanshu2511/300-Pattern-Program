/*
54321
4321
321
21
1

*/



class pattern22
{
   public static void main(String args[])

    {
      int n=5;
      for(int i=n;i>=1;i--)
       {
         for(int j=i;j>=1;j--)         

        {
         System.out.print(j);
        }
         System.out.println();
       }

    }


}