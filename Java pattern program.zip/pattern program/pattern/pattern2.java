class pattern2
{
 public static void main(String args[])
{
    for(int i=1;i<=5;i++)
        {
        for(int k=1;k<=5;k++)  
           {
             for(int j=1;j<=5;j++)   
               {
                for(int l=1;l<=5;l++);
                {
                 System.out.print(l);
                 }
                 System.out.print(" ");
                 }
                 System.out.println();
                 }
                  System.out.println();
                 }
          

    }
}