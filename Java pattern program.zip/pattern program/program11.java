

class program11
{
   public static void main(String args[])
  {
       int n=101;
       for(int i=97;i<=n;i++)
       {
              for(int j=97;j<=n;j++)
             {
                  System.out.print((char)(i));
             }
              System.out.println();
      }

   



  }

}