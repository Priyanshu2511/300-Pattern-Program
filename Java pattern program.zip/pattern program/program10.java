class program10
{
   public static void main(String args[])
  {
       
       for(int i=65;i<=69;i++)
       {
              for(int j=65;j<=69;j++)
             {
                  System.out.print((char)(j));
             }
              System.out.println();
      }

   



  }

}