// WAP to print 3 bigger no
class programif2
{
  public static void main(String args[])
     {
       int a=1,b=20,c=6;
          if(a>b)
                if(a>c)
                       System.out.print("a is bigger");
                else
                       System.out.print("c is bigger");

           else
                 if(b>c)
                        System.out.print("b is bigger");
                  else
                        System.out.print("c is bigger"); 
     }


 
}