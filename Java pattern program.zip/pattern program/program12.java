class program12
{
   public static void main(String args[])
  {
       
       for(int i=101;i>=97;i--)
       {
              for(int j=97;j<=101;j++)
             {
                  System.out.print((char)(i));
             }
              System.out.println();
      }

   



  }

}