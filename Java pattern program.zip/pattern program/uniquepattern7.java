/*
*
 *
  *
   *
    *
   *
  *
 *
*

*/
class uniquepattern7
{
  public static void main(String args[])
   {
     int n=9;
     for(int i=1;i<=n;i++)
      {
       for(int j=i;j>=1;j--)
         {
           if(j==1)
             System.out.print("*");
           else
              System.out.print(" ");   
         }
           System.out.println();
      }
      for(int i=n-1;i>=1;i--)
      {
       for(int j=i;j>=1;j--)
         {
           if(j==1)
             System.out.print("*");
           else
              System.out.print(" ");   
         }
           System.out.println();
      }


   }
}