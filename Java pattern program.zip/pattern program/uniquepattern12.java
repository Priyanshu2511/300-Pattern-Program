/*
*********
**     **
* *   * *
*  * *  *
*   *   *
*  * *  *
* *   * *
**     **
*********
*/
class uniquepattern12
{
  public static void main(String args[])
   {
  	 int n=9;
 	for(int i=1;i<=(n*2)-1;i++)
	{
		for(int j=1,j2=(n*2)-1;j<=(n*2)-1||j2>=1;j++,j2--)
		if(i==1||i==(n*2)-1||j==1||j==(n*2)-1||i==j||i==j2)
		{
			System.out.print("*");
		}
		else
		{
			System.out.print(" ");
		}

		System.out.println();
	}	
   



   }
}
