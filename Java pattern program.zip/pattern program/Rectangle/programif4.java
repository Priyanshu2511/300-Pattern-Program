//WAP  to print 5 maximum no.
class programif4
  {
    public static void main(String args[])
   {
    int a=10,b=22,c=355,d=8100,e=652;
    if(a>b)
       if(a>c)
          if(a>d)
             if(a>e)
                System.out.print("a is bigger ");
             else
               System.out.print("e is bigger");
         else
           if(d>e)
              System.out.print("d is bigger");
           else
              System.out.print("e is bigger");
           else
     if(c>d)
       if(c>e)
          System.out.print("c is bigger");
       else
          System.out.print("e is bigger");
      else
        if(d>e)
          System.out.print("d is bigger");
        else
          System.out.print("e is bigger");
  else
    if(b>c)
      if(b>d)
        if(b>e)
          System.out.print("b is bigger");
        else
          System.out.print("e is bigger");
      else
        if(d>e)
          System.out.print("d is bigger");
        else
          System.out.print("e is bigger");
    else
      if(c>d)
        if(c>e)
           System.out.print("c is bigger");
         else
           System.out.print("e is bigger");
      else
        if(d>e)
          System.out.print("d is bigger");
        else
           System.out.print("e is bigger");
                      
  }
}