class program5
{
   public static void main(String args[])
  {
       int n=69;
       for(int i=65;i<=n;i++)
       {
              for(int j=65;j<=n;j++)
             {
                  System.out.print((char)(i));
             }
              System.out.println();
      }

   



  }

}