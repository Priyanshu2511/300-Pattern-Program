class programif1
 {
   public static void main(String args[])
      {
         double p=78.90;
         if(p>=80)
            System.out.print("destinction");
         else if(p>=70)
            System.out.print("first class");
          else if(p>=60)
            System.out.print("second class");
          else if(p>=50)
            System.out.print("third class");
          else if(p>=40)
            System.out.print("fail")

      }

 }