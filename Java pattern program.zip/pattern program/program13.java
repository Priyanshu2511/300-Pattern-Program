class program13
{
   public static void main(String args[])
  {
       
       for(int i=69;i>=65;i--)
       {
              for(int j=65;j<=69;j++)
             {
                  System.out.print((char)(i));
             }
              System.out.println();
      }

   



  }

}