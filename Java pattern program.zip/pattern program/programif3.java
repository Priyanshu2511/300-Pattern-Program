// WAP to print 4 maximum no.
class programif3
{
  public static void main(String args[])
      {
           int a=50,b=2,c=3,d=40;
           if(a>b)
                  if(a>c)
                         if(a>d)
                                System.out.print("a is bigger");
                          else
                                System.out.print("d is bigger");
           else
                if(c>d)
                       System.out.print("c is bigger");
                else
                       System.out.print("d is bigger");
          else
               if(b>c)
                      if(b>d)
                             System.out.print("b is bigger");
                      else
                            System.out.print("d is bigger");

               else
                    if(c>d)
                           System.out.print("c is bigger");
                    else
                           System.out.print("d is bigger");
               
      }


}